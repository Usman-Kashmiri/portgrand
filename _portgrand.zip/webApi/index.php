<?php

 include('connection.php');
 
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json");
header("Access-Control-Allow-Headers: Content-Type");

function compressImage($source, $destination, $quality)
{
    $info = getimagesize($source);
    if ($info["mime"] == "image/jpeg") {
        $image = imagecreatefromjpeg($source);
    } elseif ($info["mime"] == "image/gif") {
        $image = imagecreatefromgif($source);
    } elseif ($info["mime"] == "image/png") {
        $image = imagecreatefrompng($source);
    }
    imagejpeg($image, $destination, $quality);
}

function imagecheck($imagetype)
{
    if (
        $imagetype == "JPG" ||
        $imagetype == "jpg" || 
        $imagetype == "PNG" ||
        $imagetype == "png" ||
        $imagetype == "jpeg" ||
        $imagetype == "JPEG" ||
        $imagetype == "docx" ||
        $imagetype == "PDF" ||
        $imagetype == "pdf" ||
        $imagetype == "DOCX" ||
        $imagetype == ""
    ) {
        return true;
    } else {
        return false;
    }
}

function subSanText($data)
{
    global $con;
    $data = trim($data);
    $data = mysqli_real_escape_string($con, $data);
    $data = filter_var($data, FILTER_SANITIZE_STRIPPED);

    return $data;
}

function sanitize($data)
{
    global $con;
    $var1 = mysqli_real_escape_string($con, $data);
    $var2 = htmlentities($var1);
    $var3 = subSanText($var2);
    $var4 = addslashes($var3);

    return strip_tags($var4);
}
 
 
switch ($_GET["page"]) {
        
    case "addPayment": 
          $invoiceData = (array) json_decode($_POST["data"]);  
        $transaction_id = subSanText($invoiceData['transaction_id']) ;
        $date = subSanText($invoiceData['date']) ;
        $amount = subSanText($invoiceData['amount']) ; 
        $payment_method = subSanText($invoiceData['payment_method_id']) ;
        $payment_status = subSanText($invoiceData['payment_status']) ;
        $card_number = subSanText($invoiceData['card_number']) ;
        $invoice_id = subSanText($invoiceData['invoice_id']) ; 
        
        $insert = mysqli_query( $con, "INSERT INTO `payment_activity`(`card_number`,`transaction_id`, `date`, `amount`, `payment_method`, `payment_status`, `invoice_id` ) VALUES 
                                                                     ('$card_number','$transaction_id','$date','$amount','$payment_method','$payment_status' ,'$invoice_id')");
        
        if ($insert) { 
            echo json_encode([
                "status" => "success",
                "msg" => "Payment succesfully inserted",
            ]);
        } else {
            echo json_encode([
                "status" => "warning",
                "msg" => "Something wrong in database",
            ]);
        }

    break;

   case 'paymentactivity': 
       
        $dateto = DateTime::createFromFormat('D M d Y H:i:s e+', $_POST['dateto']);
        $formattedDateTo = $dateto->format('Y-m-d');
        
        $dateFrom = DateTime::createFromFormat('D M d Y H:i:s e+', $_POST['datefrom']);
         $formattedDateFrom = $dateFrom->format('Y-m-d');
        
        $response = [];
        $i = 0;
        
        $select = mysqli_query($con,"SELECT paymentmethods.image as payment_methodimg , paymentmethods.label as payment_methodlabel ,payment_activity.* FROM `payment_activity` JOIN paymentmethods ON paymentmethods.id = payment_activity.payment_method WHERE payment_activity.date >= '$formattedDateTo' AND payment_activity.date <= '$formattedDateFrom' ORDER BY payment_activity.id DESC");
        if(mysqli_num_rows($select)>0){
            
            while($fetch = mysqli_fetch_array($select)){
                
                $response[$i]['id'] = $fetch['id'];
                $response[$i]['transaction_id'] = $fetch['transaction_id'];
                $response[$i]['date'] = $fetch['date'];
                $response[$i]['amount'] = $fetch['amount'];
                $response[$i]['payment_method_id'] = utf8_decode($fetch['payment_method']);
                $response[$i]['payment_method'] = utf8_decode($fetch['payment_methodlabel']);
                $response[$i]['payment_method_icon'] = $url.'webApi/uploads/paymentmethod/'.$fetch['payment_methodimg'];
                $response[$i]['payment_status'] = $fetch['payment_status'];
                $response[$i]['card_number'] = $fetch['card_number'];
                $response[$i]['invoice_id'] = $fetch['invoice_id'];
                $response[$i]['payment_token'] = '';
                
                $i++ ;
            }
                
                echo json_encode(['status'=>'success','msg'=>'Data successfully founded' ,'data'=>$response]);
        }else{
              
                echo json_encode(['status'=>'wrong','msg'=>'Data not found' ,'data'=>$response]);
        }
        
    break;
    case 'deletepaymentactivity':
           $id = mysqli_real_escape_string($con,$_POST["id"]);  
           
           $delete = mysqli_query($con,"DELETE FROM `payment_activity` WHERE `id` = '$id'");
           
        if ($delete) { 
             echo json_encode([
                "status" => "success",
                "msg" => "Payment succesfully deleted",
            ]);
        } else {
            echo json_encode([
                "status" => "warning",
                "msg" => "Something wrong in database",
            ]);
        }
        break;
    case 'updatepaymentactivity':
            $data = (array) json_decode($_POST["data"]);  
            $id =subSanText($data["id"]);  
            $transaction_id = subSanText($data['transaction_id']) ;
            $date = subSanText($data['date']) ;
            $amount = subSanText($data['amount']) ; 
            $payment_method = subSanText($data['payment_method_id']) ;
            $payment_status = subSanText($data['payment_status']) ;
            $card_number = subSanText($data['card_number']) ;
            $invoice_id = subSanText($data['invoice_id']) ; 
           
           $delete = mysqli_query($con,"UPDATE `payment_activity` SET `transaction_id`='$transaction_id',`date`='$date',`amount`='$amount',`card_number`='$card_number',`payment_method`='$payment_method',`payment_status`='$payment_status',`invoice_id`='$invoice_id' WHERE `id` = '$id'");
           
        if ($delete) { 
             echo json_encode([
                "status" => "success",
                "msg" => "Payment succesfully updated",
            ]);
        } else {
            echo json_encode([
                "status" => "warning",
                "msg" => "Something wrong in database",
            ]);
        }
        break;
        case "addContent": 
                $Data = (array) json_decode($_POST["data"]);  
                $title = subSanText($Data['title']) ;
                $date_published = subSanText($Data['date_published']) ;
                $reach = subSanText($Data['reach']) ;
                $engagements = subSanText($Data['engagements']) ; 
                $like_reactions = subSanText($Data['like_reactions']) ; 
                
                
                
                    if (!empty($_FILES["file"]["type"])) {
                        $image = date("dmYHis") . str_replace(" ", "", basename($_FILES["file"]["name"]));
                        $picture_type = str_replace( "", "", basename($_FILES["file"]["type"]) );
                        $path_picture = "uploads/socialcontent/" . $image; 
                        if ($picture_type != "") {
                            move_uploaded_file($_FILES["file"]["tmp_name"], $path_picture);
                        }
                    }else{
                        $image = '';
                    }
                            
                
                $insert = mysqli_query( $con, "INSERT INTO `socialcontent`(`title`,`image`,`date_published`, `reach`, `engagements`, `like_reactions` ) VALUES ('$title','$image','$date_published','$reach','$engagements','$like_reactions')");
                
                if ($insert) { 
                    echo json_encode([
                        "status" => "success",
                        "msg" => "Content succesfully inserted",
                    ]);
                } else {
                    echo json_encode([
                        "status" => "warning",
                        "msg" => "Something wrong in database",
                    ]);
                }
        
           break;
        case 'content': 
       
            $dateto = DateTime::createFromFormat('D M d Y H:i:s e+', $_POST['dateto']);
            $formattedDateTo = $dateto->format('Y-m-d');
        
            $dateFrom = DateTime::createFromFormat('D M d Y H:i:s e+', $_POST['datefrom']);
             $formattedDateFrom = $dateFrom->format('Y-m-d');
        
            $response = [];
            $i = 0;
        
        $select = mysqli_query($con,"SELECT * FROM `socialcontent` WHERE `date_published` >= '$formattedDateTo' AND `date_published` <= '$formattedDateFrom' ORDER BY `id` DESC");
        if(mysqli_num_rows($select)>0){ 
            while($fetch = mysqli_fetch_array($select)){
                
                $response[$i]['id'] = $fetch['id'];
                $response[$i]['title'] = $fetch['title'];
                $response[$i]['date_published'] = $fetch['date_published'];
                $response[$i]['reach'] = $fetch['reach'];
                $response[$i]['engagements'] = $fetch['engagements'];
                $response[$i]['like_reactions'] = utf8_decode($fetch['like_reactions']); 
                $response[$i]['image'] = $url.'webApi/uploads/socialcontent/'.$fetch['image'];
                
                $i++ ;
            }
                
                echo json_encode(['status'=>'success','msg'=>'Data successfully founded' ,'data'=>$response]);
        }else{
              
                echo json_encode(['status'=>'wrong','msg'=>'Data not found' ,'data'=>$response]);
        }
        
    break;
    
    case 'deleteContent':
         $id = mysqli_real_escape_string($con,$_POST["id"]);  
           
           $delete = mysqli_query($con,"DELETE FROM `socialcontent` WHERE `id` = '$id'");
           
        if ($delete) { 
             echo json_encode([
                "status" => "success",
                "msg" => "Payment succesfully deleted",
            ]);
        } else {
            echo json_encode([
                "status" => "warning",
                "msg" => "Something wrong in database",
            ]);
        }
        
    break;
     case 'updatecontent': 
            $Data = (array) json_decode($_POST["data"]);  
            $id = subSanText($Data['id']) ;
            $title = subSanText($Data['title']) ;
            $date_published = subSanText($Data['date_published']) ;
            $reach = subSanText($Data['reach']) ;
            $engagements = subSanText($Data['engagements']) ; 
            $like_reactions = subSanText($Data['like_reactions']) ; 
            
            $picture = date('dmYHis') . str_replace(" ", "", basename($_FILES["file"]["name"]));
            $picture_type = str_replace("", "", basename($_FILES["file"]["type"]));
            
            $path_picture = "uploads/socialcontent/" . $picture;
            $check_email = mysqli_query($con, "SELECT * FROM `socialcontent` where `id` = '$id'");
            $fetch_check = mysqli_fetch_array($check_email);
            
            if (!empty($picture_type)) {
                if (!imagecheck($picture_type)) {
                    echo "image";
                    exit();
                }
            
                $scan_logo = $fetch_check['image'];
                $file_path = "uploads/socialcontent/" . $scan_logo;
                if (file_exists($file_path)) {
                    unlink($file_path);
                }
            
                $updatelogo = mysqli_query($con, "UPDATE `socialcontent` SET `image`='$picture' WHERE `id` ='$id'");
                move_uploaded_file($_FILES["file"]["tmp_name"], $path_picture);
            }

            
           $delete = mysqli_query($con,"UPDATE `socialcontent` SET `title`='$title',`date_published`='$date_published',`reach`='$reach',`engagements`='$engagements',`like_reactions`='$like_reactions'  WHERE `id` = '$id'");
           
        if ($delete) { 
             echo json_encode([
                "status" => "success",
                "msg" => "Payment succesfully updated",
            ]);
        } else {
            echo json_encode([
                "status" => "warning",
                "msg" => "Something wrong in database",
            ]);
        }
        break;
    
    
  
}
function generateRandomString($length = 160)
{
    $characters =
        "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $charactersLength = strlen($characters);
    $randomString = "";
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
?>
