<?php
@session_start([
    'cookie_lifetime' => 86400,
]); 
$con = mysqli_connect("localhost","u958043154_portgrand","sdfgwer#@34L)099","u958043154_portgrand") or die("connection error");

$protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$url = $protocol. $_SERVER['HTTP_HOST']."/";
$url_curent = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; 

@define('CONNECT_EMAIL_CLIENT','noreply@xiom.com');

// PAGE NAME GET
$mypage= basename($_SERVER['PHP_SELF'], ".php");

// SETTING GET
$settingquery= mysqli_query($con,"SELECT * FROM `settings`");
$settinginfo=mysqli_fetch_array($settingquery);
?>